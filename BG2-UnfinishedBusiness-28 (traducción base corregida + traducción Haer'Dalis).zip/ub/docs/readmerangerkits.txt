Ice, here's something for the ReadMe:

Andyr :)

1. Justifier ranger kit.

Thanks to Alarielle and rreinier for testing, and CamDawg for some code. :)

This component makes the Justifier kit available to the PC. The description of the kit is as follows:

JUSTIFIER: Some expeditions are so demanding and some foes so dangerous that they require the attention of a highly trained specialist whose combat skills far exceed those of the typical ranger. Enter the Justifier, a master tactician whose military instincts, fighting versatility, and steely nerves places him in the first rank of elite warriors.

For a determined Justifier no job is too difficult, no enemy too formidable. Their proficiency with weapons gives them an edge in combat, though the smaller time devoted to magical training leaves them slightly lacking in that department.

They must be of Lawful Good alignmment.

Advantages:
-  +10% to stealth ability
-  +1 to speed factor and thac0 per 10 levels

Disadvantages:
-  No access to Charm Animal ability
-  Spell casting ability limited to:
Cure Light Wounds and Armour of Faith once each per day from level 8
Luck and Remove Fear once each per day from level 10
Draw Upon Holy Might once per day from level 12

2. Feralan ranger kit.

This component makes the Feralan kit available to the PC. The description of the kit is as follows:

FERALAN: What happens to children who wander in the wilderness and are never recovered? Or worse, those who are abandoned there? Many succumb to the dangers of the wild, but a fortunate few are taken in by animals, raised as a part of a lion`s brood, or a wolf`s litter. Cut off from civilization, they gradually take on the characteristics of the creatures who adopted them, forming some kind of unity with the spirit of the wild. In the process they become feralans, beings who combine the savagery of beasts with the intellect of man.

Due to their wild nature, Feralans may not be of Lawful alignment. As Rangers, they are limited to Good alignments.

Advantages:
-  +10% to Stealth ability.
-  Gains +1 AC at first level, and a further bonus of +1 AC per 5 levels.
-  May go into a Feral Rage once per day per 10 levels. The enraged state lasts for 60 seconds, and grants a bonus of +2 to hit, damage, and AC, and immunity to charm, hold and fear, maze, imprisonment, stun and sleep. He also gains 15 temporary hit points.
-  May cast Call of the Wild once per day. This summons an animal companion who will fight for the caster for 3 rounds + 1 round/level. More powerful creatures are summoned at higher levels.

Disadvantages:
-  Becomes winded after Feral Rage. While he's winded he receives -2 to hit, -2 to damage and a +2 penalty to armor class.
-  Limited to one proficiency point in Bastard Sword, Long Sword, Short Sword, Two - Handed Sword, Katana, Scimitar, Halberd, Flail and Crossbow.
-  May not wear any armour or use Large Shields.
-  Maximum Charisma is 2 points lower than a standard member of the race.
