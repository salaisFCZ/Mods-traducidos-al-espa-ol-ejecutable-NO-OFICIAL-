Andyr's Kalah expansion component for Unfinished Business

README CONTENTS

What was promised to Kalah, and who promised it to him?  How did he suddenly acquire his powers?  This mod small attempts to give my version of the answers.

You need to not have done the circus tent quest for this to activate.  The original quest proceeds as normal, though when you leave the circus tent afterwards the new section should proceed.  It is a short addition, with several possible outcomes depending on your choices.

This component was designed and created by Andyr.  Thanks to Beaz for making the inventory BAM for the magic lamp, and to Seifer, Grey Acumen, MERLANCE, Sovran, Flunders, RReinier, SilverRose and SnowKing for beta-testing.

SPOILERS (Walkthrough)

1. Proceed with the circus quest as normal.
2. Afterwards and outside, a girl named Myara should come up to you.  Talk to her and get the lamp.
3. Go to the Crooked Crane in the City Gates district.
4. Talk to Jafir upstairs.
5. Use the lamp, for what you will...

Changes for second beta (not needed for final ReadMe, Icelus):

1. Spelling/grammar fixes.
2. Instead of automatically summoning the genie after the quest is done, you get to keep the lamp to use when you want to.
3. Hopefully fixed the undead Kalah's broken script.
4. Added some more options to the Wish.
