Unfinished Business do Baldurs Gate II SoA (+/- ToB)
Autor: Icelus
T�umaczenie: Riklaunim

Strona moda: http://home.houston.rr.com/icelus/ub/
Polska strona z opisem tego i innych mod�w: www.crpg.riklaunim.noi.pl

Mod ten przywraca wyci�te zadania z gry (cz�� SoA). S� to: porwanie Boo, The Suna Seni/Valygar Zwi�zek mi�osny :), Kotek i myszka - Bodhi gania nas po Czarowi�zach, Rozszerzone zadanie z Ilitem, Zadanie z Pai'na, Dodatkowe 4 dodatkowe losowe spotkania w Athkatli, Dodanie przedmiot�w, Inne. Ten mod dodaje tre��, kt�ra by�a w grze, ale zosta�a "usuni�ta" przed oficjaln� premier� gry.

Wi�cej szczeg��w na stronach www i w angielskim readme.

### Instalacja ###
- Wrzu� rozpakowanego moda do katalogu z gr�
- Uruchom Setup-ub.exe
- Post�puj zgodnie ze "wskaz�wkami"
-- Rozpocznij now� gr�
